/*
 * my_html_web_check.c
 *
 *  Created on: 2019��5��15��
 *      Author: MasterChief
 */

#include "my_html_web_check.h"

void ICACHE_FLASH_ATTR my_html_web_cache1() {
	my_html_cache_head();
	u8 * str = "<body><table border=\"1\">"
			"<tr><td colspan=\"2\" align=\"center\">"
			"--- Web Checker ---</td></tr>"
			"<form action=\"/web\" method=\"post\">";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str);
	//os_free(str);
}

void ICACHE_FLASH_ATTR my_html_web_cache2() {
	u8 * str = "<tr><td colspan=\"2\" align=\"center\">"
			"<input type=\"submit\" value=\"SUBMIT\" /></td></tr>"
			"</form>"
			"<tr><td colspan=\"2\" align=\"center\">";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, "%s",str);
	//os_free(str);
}
void ICACHE_FLASH_ATTR my_html_web_cache3() {
	u8 * str1 = "</td></tr>"
			"<tr><td colspan=\"2\" align=\"center\">";
	u8 * str2 = "</td></tr></table></body></html>\n\n";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, "%s",str1);
	//os_free(str1);
	my_html_cache_links();
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, "%s",str2);
	//os_free(str2);
}

//�����ѱ����վ����Ϣ
void ICACHE_FLASH_ATTR my_html_web_cache_webinfo() {
	u8 * msg = NULL;

	//my_Web_Checker_WebSite_init(); //��ȡ�ѱ������Ϣ
	//����
	msg = "<tr><td>URL(http://):</td><td>"
			"<input type=\"text\" name=\"weburl\" value=\"";
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	//url
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body, "%s:%d%s",
			my_sys.web_info.domain_name, my_sys.web_info.port,
			my_sys.web_info.path);
	//����
	msg = "\" /></td></tr>"
			"<tr><td colspan=\"2\">"
			"eg1:www.baidu.com<br>"
			"eg2:www.someweb.com:8088/something<br>"
			"eg3:127.0.0.1:8088/index.html"
			"</td></tr>";
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	//����
	msg = "<tr><td>Interval(s):</td><td>"
			"<input type=\"text\" name=\"itl\" value=\"";
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	//���ʱ��
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body, "%d",
			my_sys.web_info.interval);
	//����
	msg = "\" /></td></tr><tr><td>Active:</td><td>";
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	msg = "<input type=radio name=ac value=1 %s>ON "
			"<input type=radio name=ac value=0 %s>OFF</td></tr>";
	if (my_sys.web_checker.actived == 1) {
		my_sys.http_session.P_cache_body +=
		os_sprintf(my_sys.http_session.P_cache_body, msg, "checked", "");
	} else {
		my_sys.http_session.P_cache_body +=
		os_sprintf(my_sys.http_session.P_cache_body, msg, "", "checked");
	}
	//os_free(msg);
}

//�����źŵ�����
void ICACHE_FLASH_ATTR my_html_web_cache_led() {
	u8 * msg = NULL;
	msg = "<tr><td colspan=2 align=\"center\">"
			"GPIO Pin No. for Signal LED</td></tr>"
			"<tr><td><input type=text name=gn value=%d></td>"
			"<td>GPIO No.:4,5,12,13,14,16</td></tr>";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, msg,
			my_sys.web_checker.led_sig.gpio_no);
}

//��ȡ��վ��״̬
u8 * ICACHE_FLASH_ATTR my_html_web_read_webstatus() {
	u8 * msg = NULL;
	switch (my_sys.web_info.F_Web_Status) {
	case 0:
		msg = "Unchecked!";
		break;
	case 1:
		msg = "Checking!";
		break;
	case 2:
		msg = "Is OK!";
		break;
	case 3:
		msg = "Can't read!";
		break;
	default:
		break;
	}
	return msg;
}

//��������
u8 * ICACHE_FLASH_ATTR my_html_web_save_webinfo() {
	u8 * weburl = NULL;
	u8 * itl = NULL;
	u8 * ac = NULL;
	u8 * gn=NULL;

	weburl = my_HTTP_Server_Parmeter("weburl", PARMETER_IN_BODY);
	itl = my_HTTP_Server_Parmeter("itl", PARMETER_IN_BODY);
	ac = my_HTTP_Server_Parmeter("ac", PARMETER_IN_BODY);
	gn = my_HTTP_Server_Parmeter("gn", PARMETER_IN_BODY);

	if (weburl == NULL || itl == NULL) {	//��
		//os_free(weburl);
		//os_free(itl);
		//os_free(ac);
		return "Web URL or Interval is empty!";
	}
	//�źŵ�
	if(gn==NULL){
		my_sys.web_checker.led_sig.gpio_no=DEFAULT_LED_SIG_GPIO;
	}else{
		my_sys.web_checker.led_sig.gpio_no=atoi(gn);
		if(!my_SYS_GPIO_No_check(my_sys.web_checker.led_sig.gpio_no)){
			my_sys.web_checker.led_sig.gpio_no=DEFAULT_LED_SIG_GPIO;
			my_GPIO_set(my_sys.web_checker.led_sig.gpio_no);//������Ӧ���gpio����
		}
	}

	if(ac==NULL){
		my_sys.web_checker.actived=DEFAULT_WEB_CHECKER_ACTIVE;
	}else{
		my_sys.web_checker.actived=atoi(ac);
	}
	//os_free(ac);
	//my_Str_replace(weburl, "%2F", "/", weburl);	//�͵��滻��ת���ַ���
	//my_Str_replace(weburl, "%3A", ":", weburl);	//�͵��滻��ת���ַ���
	my_Str_URL_ES2CE(weburl,my_sys.http_session.cache);//�滻ת���ַ���
	//os_sprintf(weburl,my_sys.http_session.cache);//��д
	weburl=my_sys.http_session.cache;//ֱ��ָ�򻺴棬�Ȼ�д�����򵥣�ʡʱ
	my_Web_Checker_Save_flash(weburl, itl);

	my_Web_Checker_init();
	return "Saved!";
}

//ִ��ҳ�洦��
void ICACHE_FLASH_ATTR my_html_web_do() {
	u8 * msg = NULL;

	if (my_sys.http_session.F_method == HTTP_METHOD_POST) {
		msg = my_html_web_save_webinfo();
	} else {
		msg = my_html_web_read_webstatus();
	}

	my_html_web_cache1();
	my_html_web_cache_webinfo();
	my_html_web_cache_led();
	my_html_web_cache2();

	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	if (my_sys.web_info.check_time != NULL) {
		my_sys.http_session.P_cache_body += os_sprintf(
				my_sys.http_session.P_cache_body, " @ %s",
				my_sys.web_info.check_time);
	}

	my_html_web_cache3();

	//my_HTTP_Server_cache_header(200);	//ͷ
	//my_HTTP_Server_send_cache();

}
