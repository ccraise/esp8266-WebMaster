/*
 * my_html_gpio.c
 *
 *  Created on: 2019��5��30��
 *      Author: MasterChief
 */

#include "my_html_gpio.h"


void ICACHE_FLASH_ATTR my_html_gpio_cache1() {
	my_html_cache_head();
	u8 * str = "<body><table border=\"1\">"
			"<tr><td colspan=2 align=\"center\">--- GPIO Control ---</td></tr>"
			"<form action=\"/gpio\" method=\"post\">"
			"<tr><td colspan=2 align=\"center\">GPIO Output</td></tr>";

	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str);
	//os_free(str);
}

void ICACHE_FLASH_ATTR my_html_gpio_cache2() {
	u8 * str1 = "</td></tr><tr><td colspan=2 align=\"center\">";
	u8 * str2 = "</td></tr></table></body></html>\n\n";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str1);
	//os_free(str1);
	my_html_cache_links();
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str2);
	//os_free(str2);
}

//gpio������ñ���
void ICACHE_FLASH_ATTR my_html_gpio_cache_outctrl(u8* gpio_no,u8 v) {
	u8* msg = "<tr><td align=center>GPIO(4,5,12-14,16)</td>"
			"<td align=center>Output Value</td>"
			"<tr><td><input type=text name=gpo value=\"%s\" /></td>"
			"<td><input type=radio name=otv value=\"1\" %s>High(1)"
			"<input type=radio name=otv value=\"0\" %s />Low(0)</td></tr>";

	if(v==0){
		my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, msg,gpio_no,"","checked");
	}else{
		my_sys.http_session.P_cache_body += os_sprintf(
					my_sys.http_session.P_cache_body, msg,gpio_no,"checked","");
	}

}

//gpio��ȡ���ñ���
void ICACHE_FLASH_ATTR my_html_gpio_cache_read(u8* gpio_no,u8* v) {
	u8* msg = "<tr><td colspan=2 align=\"center\">GPIO Read(Input Mode Only)</td></tr>"
			"<tr><td align=center>GPIO(4,5,12-14,16)</td>"
			"<td align=center>Read Value</td>"
			"<tr><td><input type=text name=gpr value=\"%s\" /></td>"
			"<td align=center>%s</td></tr>"
			"<tr><td colspan=2 align=center>"
			"<input type=submit name=SUBMIT /></td></tr>"
			"</form>";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, msg,gpio_no,v);
}

//adc read
void ICACHE_FLASH_ATTR my_html_cache_adc(){
	//system_adc_read_fast�����ٹر�wifi�����ʹ�ã�������system_adc_read
	//���ص�ģ��ܽŵĵ�ѹ������0-1.0v����ȡ����ֵ�ĵ�λ�� 1/1024 v
	int adc=system_adc_read();
	u8* msg="<tr><td colspan=2 align=\"center\">ADC Read(0~1.0v)</td></tr>"
			"<tr><td colspan=2 align=\"center\">%d * 1/1024 v</td></tr>"
			"<tr><td colspan=2 align=center>";
	my_sys.http_session.P_cache_body += os_sprintf(
				my_sys.http_session.P_cache_body, msg,adc);
}

//gpio����
u8* ICACHE_FLASH_ATTR my_html_gpio_ctrl(){
	u8* gpo=NULL;//������Ƶ�gpio��
	u8* otv=NULL;//���ֵ
	u8* gpr=NULL;//������Ƶ�gpio��
	u8 gpio_out;
	u8 gpio_read;
	u8 gpio_value;
	u8* msg=NULL;

	gpo = my_HTTP_Server_Parmeter("gpo", PARMETER_IN_BODY);
	otv = my_HTTP_Server_Parmeter("otv", PARMETER_IN_BODY);
	gpr = my_HTTP_Server_Parmeter("gpr", PARMETER_IN_BODY);

	if(gpo==NULL||gpr==NULL){
		msg="Input error!";
		my_html_gpio_cache_outctrl("",0);
		my_html_gpio_cache_read("","No value");
		return msg;
	}else{
		gpio_out=atoi(gpo);//ת����
		gpio_read=atoi(gpr);//ת��
	}
	//�������
	if(!my_SYS_GPIO_No_check(gpio_out)){//�Ϸ��Լ��
		my_html_gpio_cache_outctrl("",0);
		msg="Input error!";
	}else{//�Ϸ��Լ��ͨ��
		my_GPIO_set(gpio_out);//������Ӧ���gpio����
		if(otv==NULL){//����ֵ���
			gpio_value=0;
		}else{
			gpio_value=atoi(otv);
		}
		//����ֵ��д��ô������Ϊ�˷�ֹweb�˴�����������
		if(gpio_value==0){
			my_GPIO_output(gpio_out,0);
		}else{
			my_GPIO_output(gpio_out,1);
		}
		my_html_gpio_cache_outctrl(gpo,gpio_value);//�������
	}
	//��ȡ
	if(!my_SYS_GPIO_No_check(gpio_read)){//�Ϸ��Լ��
		my_html_gpio_cache_read("","No value");
		msg="Input error!";
	}else{
		gpio_value=my_GPIO_read(gpio_read);
		os_printf("----mark gpio value:%d\n--",gpio_value);
		if(gpio_value==0){
			otv="Low(0)";
		}else{
			otv="High(1)";
		}
		my_html_gpio_cache_read(gpr,otv);
	}
	if(msg==NULL){
		return "Done!";
	}else{
		return msg;
	}

}



void ICACHE_FLASH_ATTR my_html_gpio_do() {
	u8 * msg = NULL;

	my_html_gpio_cache1();

	if (my_sys.http_session.F_method == HTTP_METHOD_POST){
		msg=my_html_gpio_ctrl();
	}else{
		msg="Welcome!";
		my_html_gpio_cache_outctrl("",0);
		my_html_gpio_cache_read("","No value");
	}

	my_html_cache_adc();

	my_sys.http_session.P_cache_body += os_sprintf(
				my_sys.http_session.P_cache_body, "%s",msg);

	my_html_gpio_cache2();

}
