/*
 * my_html_config_sta.c
 *
 *  Created on: 2019��5��10��
 *      Author: MasterChief
 */

#include "my_html_config_sta.h"

void ICACHE_FLASH_ATTR my_html_config_sta_cache1() {
	my_html_cache_head();
	u8 * str ="<body><table border=\"1\">"
					"<tr><td colspan=\"2\" align=\"center\">"
					"--- WiFi Config: STA ---</td></tr>"
					"<form action=\"/sta\" method=\"post\">";

	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str);
	//os_free(str);

}

void ICACHE_FLASH_ATTR my_html_config_sta_cache2() {
	u8 * str1 = "</td></tr>"
			"<tr><td colspan=\"2\" align=\"center\">";
	u8 * str2 = "</td></tr></table></body></html>\n\n";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str1);
	//os_free(str1);
	my_html_cache_links();
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, "%s",str2);
	//os_free(str2);
}

//װ�䵱ǰ������Ϣ
void ICACHE_FLASH_ATTR my_html_config_sta_cache_current() {
	struct station_config config;
	u8 * msg = NULL;
	u8 * ssid = NULL;
	u8 * pass = NULL;

	if (wifi_station_get_config(&config)) {
		ssid = config.ssid;
		pass = config.password;
	}
	//ssid
	msg = "<tr><td>SSID:</td><td><input type=\"text\" name=\"ssid\" value=\"";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, "%s",ssid);
	//os_free(ssid);
	msg = "\" /></td></tr>";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	//pass
	msg = "<tr><td>PASS:</td><td><input type=\"text\" name=\"pass\" value=\"";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", pass);
	//os_free(pass);
	//os_free(&config);
	msg = "\" /></td></tr>";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);

	msg = "<tr><td colspan=\"2\" align=\"center\">"
			"<input type=\"submit\" value=\"SUBMIT\" /></td></tr></form>"
			"<tr><td colspan=\"2\" align=\"center\">";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
}

//װ�����ý��
u8 * ICACHE_FLASH_ATTR my_html_config_sta_save_config() {
	struct station_config STA_Config;	// STA�����ṹ��
	u8 * ssid = NULL;
	u8 * pass = NULL;

	ssid = my_HTTP_Server_Parmeter("ssid", PARMETER_IN_BODY);
	pass = my_HTTP_Server_Parmeter("pass", PARMETER_IN_BODY);

	if (pass == NULL) {	//������
		pass = "";
	}
	if (ssid == NULL) {	//���ssid�ǿյ�
		return "SSID is empty!";
	} else {	//����ʼ����wifi

		my_STA_init(ssid,pass);

		wifi_station_connect();	// ESP8266����WIFI
		return "Saved!";
	}

}

//ִ��sta����ҳ�洦��
void ICACHE_FLASH_ATTR my_html_config_sta_do() {
	u8 * msg = NULL;

	if (my_sys.http_session.F_method == HTTP_METHOD_POST) {	//�����post
		msg = my_html_config_sta_save_config();
	} else {
		msg = "Welcome!";
	}

	my_html_config_sta_cache1();	//��һ���֣�����
	my_html_config_sta_cache_current();	//��ǰ����

	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, msg);
	//os_free(msg);
	my_html_config_sta_cache2();	//��2����

	//my_HTTP_Server_cache_header(200);	//httpͷ
	//my_HTTP_Server_send_cache();

}

