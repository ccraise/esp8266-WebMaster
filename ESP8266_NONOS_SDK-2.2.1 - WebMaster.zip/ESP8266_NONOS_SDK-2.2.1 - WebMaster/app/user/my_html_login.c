/*
 * my_html_login.c
 *
 *  Created on: 2019��5��13��
 *      Author: MasterChief
 */

#include "my_html_login.h"

void ICACHE_FLASH_ATTR my_html_login_cache1() {
	my_html_cache_head();
	u8 * str ="<body><form action=\"/login\" method=\"post\">"
					"<table border=\"1\">"
					"<tr><td colspan=\"2\" align=\"center\">--- ESP8266: Login ---</td></tr>"
					"<tr><td>UserID:</td><td><input type=\"text\" name=\"userid\" /></td></tr>"
					"<tr><td>Password:</td><td><input type=\"text\" name=\"pass\" /></td></tr>"
					"<tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" value=\"SUBMIT\" /></td></tr>"
					"<tr><td colspan=\"2\" align=\"center\">";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str);
	//os_free(str);
}

void ICACHE_FLASH_ATTR my_html_login_cache2() {
	u8 * str = "</td></tr></table></form></body></html>\n\n";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str);
	//os_free(str);
}

void ICACHE_FLASH_ATTR my_html_login_do() {

	u8 * userid = NULL;
	u8 * pass = NULL;
	u8 * msg = NULL;

	if (my_sys.http_session.F_method == HTTP_METHOD_POST) { //�����post
		userid = my_HTTP_Server_Parmeter("userid", PARMETER_IN_BODY);
		pass = my_HTTP_Server_Parmeter("pass", PARMETER_IN_BODY);

		if (userid == NULL || pass == NULL) {	//������
			msg = "UserID or Password is empty!";
		} else {	//����ʼ��֤����¼
			if (os_strcmp(userid, my_sys.user_info.userid) == 0 &&
			os_strcmp(pass, my_sys.user_info.password) == 0) {
				my_HTTP_Server_Session_active();
				//os_free(userid);
				//os_free(pass);
				//os_free(msg);
				os_printf("HTTP_Server -> my_html_index_do()\n");
				my_html_index_do();	//��¼�ɹ���ת��index
				return;
				//msg = "<a href=\"/index\">success!</a>";
			} else {
				//os_free(userid);
				//os_free(pass);
				msg = "userid or password not match!";
			}
		}
	} else {
		//my_sys.http_session.time_mark = 0;	//sessionʧЧ
		msg = "Welcome!";
	}

	my_html_login_cache1();
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, "%s", msg);
	//os_free(msg);

	my_html_login_cache2();

	//my_HTTP_Server_cache_header(200);
	//my_HTTP_Server_send_cache();

}
