/*
 * my_html_sntp.c
 *
 *  Created on: 2019��5��17��
 *      Author: MasterChief
 */

#include "my_html_sntp.h"

void ICACHE_FLASH_ATTR my_html_sntp_cache1() {
	my_html_cache_head();
	u8 * str ="<body><table border=\"1\">"
					"<tr><td colspan=\"2\" align=\"center\">--- SNTP Config ---</td></tr>"
					"<form action=\"/sntp\" method=\"post\">";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str);
	//os_free(str);

}

void ICACHE_FLASH_ATTR my_html_sntp_cache2() {
	u8 * str1 = "</td></tr><tr><td colspan=\"2\" align=\"center\">";
	u8 * str2 = "</td></tr></table></body></html>\n\n";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str1);
	//os_free(str1);
	my_html_cache_links();
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str2);
	//os_free(str2);
}

//��ȡsntp������Ϣ
void ICACHE_FLASH_ATTR my_html_cache_sntp() {
	u8 * msg = NULL;
	sint8 i;
	msg = "<tr><td>Server %d (Domain Name):</td>"
			"<td><input type=\"text\" name=\"dm%d\" value=\"%s\" /></td></tr>";

	for (i = 0; i < 3; i++) {
		my_sys.http_session.P_cache_body += os_sprintf(
				my_sys.http_session.P_cache_body, msg, i, i,
				sntp_getservername(i));
	}
	//os_free(msg);
	msg = "<tr><td>Time Zone:</td><td><select name=\"tzone\">";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	msg = "<option value=\"%d\"%s>%d</option>";

	for (i = -11; i <= 13; i++) {
		if (my_sys.sntp_info.time_zone == i) {
			my_sys.http_session.P_cache_body += os_sprintf(
					my_sys.http_session.P_cache_body, msg, i, " selected", i);
		} else {
			my_sys.http_session.P_cache_body += os_sprintf(
					my_sys.http_session.P_cache_body, msg, i, "", i);
		}

	}
	//os_free(msg);
	msg = "</select></td></tr>";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	//����
	msg = "<tr><td colspan=\"2\" align=\"center\">"
			"<input type=\"submit\" value=\"SUBMIT\" /></td></tr>"
			"</form>"
			"<tr><td colspan=\"2\" align=\"center\">";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
}

//����sntp������Ϣ
u8 * ICACHE_FLASH_ATTR my_html_sntp_save() {
	u8 * t = NULL;
	//os_free(my_sys.sntp_info.domain0);
	//os_free(my_sys.sntp_info.domain1);
	//os_free(my_sys.sntp_info.domain2);
	my_sys.sntp_info.domain0 = my_HTTP_Server_Parmeter("dm0", PARMETER_IN_BODY);
	my_sys.sntp_info.domain1 = my_HTTP_Server_Parmeter("dm1", PARMETER_IN_BODY);
	my_sys.sntp_info.domain2 = my_HTTP_Server_Parmeter("dm2", PARMETER_IN_BODY);

	t = my_HTTP_Server_Parmeter("tzone", PARMETER_IN_BODY);
	if (t != NULL) {
		my_sys.sntp_info.time_zone = atoi(t);
		//os_free(t);
	}

	my_SNTP_init(); //���³�ʼ��
	my_SYS_Config_save_flash(); //��������
	return "Saved!";
}

void ICACHE_FLASH_ATTR my_html_sntp_do() {
	u8* msg = NULL;

	if (my_sys.http_session.F_method == HTTP_METHOD_POST) {
		msg = my_html_sntp_save();
	} else {
		msg = my_SNTP_read();
	}

	my_html_sntp_cache1();

	my_html_cache_sntp();

	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	my_html_sntp_cache2();

	//my_HTTP_Server_cache_header(200);
	//my_HTTP_Server_send_cache();

}
