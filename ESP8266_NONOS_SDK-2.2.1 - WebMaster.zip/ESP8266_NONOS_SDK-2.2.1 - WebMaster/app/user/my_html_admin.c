/*
 * my_html_admin.c
 *
 *  Created on: 2019��5��20��
 *      Author: MasterChief
 */

#include "my_html_admin.h"

void ICACHE_FLASH_ATTR my_html_admin_cache1() {
	my_html_cache_head();
	u8 * str = "<body><table border=\"1\">"
			"<tr><td colspan=\"2\" align=\"center\">--- Admin ---</td></tr>"
			"<form action=\"/admin\" method=\"post\">";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, "%s",str);
	//os_free(str);
}

void ICACHE_FLASH_ATTR my_html_admin_cache2() {
	u8 * str1 = "</td></tr><tr><td colspan=\"2\" align=\"center\">";
	u8 * str2 = "</td></tr></table></body></html>\n\n";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str1);
	//os_free(str1);
	my_html_cache_links();
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, "%s",str2);
	//os_free(str2);
}

//��ǰ����
void ICACHE_FLASH_ATTR my_html_admin_cache_current() {
	u8 * msg = NULL;

	msg = "<tr><td>User ID:</td><td>"
			"<input type=\"text\" name=\"userid\" value=\"";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, msg);
	//os_free(msg);
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, my_sys.user_info.userid);

	msg = "\" readonly /></td></tr>";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, msg);
	//os_free(msg);
	msg = "<tr><td>Password:</td><td>"
			"<input type=\"text\" name=\"pass\" value=\"";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, msg);
	//os_free(msg);
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", my_sys.user_info.password);

	msg = "\" /></td></tr>";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, msg);
	//os_free(msg);
	msg = "<tr><td colspan=\"2\" align=\"center\">"
			"<input type=\"submit\" value=\"SUBMIT\"></td></tr></form>";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, msg);
	//os_free(msg);
	msg = "<tr><td colspan=\"2\" align=\"center\">";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, msg);
	//os_free(msg);
}

//��������
u8 * ICACHE_FLASH_ATTR my_html_admin_save_config() {
	//u8 * userid = NULL;
	u8 * pass = NULL;
	//u8 * msg = NULL;

	//userid = my_HTTP_Server_Parmeter("userid", PARMETER_IN_BODY);
	pass = my_HTTP_Server_Parmeter("pass", PARMETER_IN_BODY);

	if (pass == NULL) {
		return "Password is empty!";
	} else {
		my_sys.user_info.password = pass;
		my_SYS_Config_save_flash();

		return "Saved!";
	}
}

void ICACHE_FLASH_ATTR my_html_admin_do() {
	u8 * msg = NULL;
	if (my_sys.http_session.F_method == HTTP_METHOD_POST) { //�����post
		msg = my_html_admin_save_config();
	} else {
		msg = "Welcome!";
	}

	my_html_admin_cache1();
	my_html_admin_cache_current();
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body, msg);
	//os_free(msg);
	my_html_admin_cache2();

	//my_HTTP_Server_cache_header(200);
	//my_HTTP_Server_send_cache();

}
