/*
 * my_html_uart_rcv.c
 *
 *  Created on: 2019��5��29��
 *      Author: MasterChief
 */


#include "my_html_uart_rcv.h"


void ICACHE_FLASH_ATTR my_html_uart_rcv_cache1() {
	my_html_cache_head();
	u8 * str = "<body><table border=\"1\">"
			"<tr><td align=\"center\">--- UART Receive ---</td></tr>"
			"<tr><td align=\"center\">UART Last Receive</td></tr>";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str);
	//os_free(str);
}

void ICACHE_FLASH_ATTR my_html_uart_rcv_cache2() {
	u8 * str1 = "</td></tr><tr><td align=\"center\">";
	u8 * str2 = "</td></tr></table></body></html>\n\n";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str1);
	//os_free(str1);
	my_html_cache_links();
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str2);
	//os_free(str2);
}

//����uart�ϴ��յ�������
u8 * ICACHE_FLASH_ATTR my_html_uart_rcv_cache_msg() {
	u8 * msg = NULL;
	msg = "<tr><td align=\"center\">"
			"<textarea cols=50 rows=4 readonly>%s</textarea>"
			"</td></tr><tr><td align=\"center\">";
	if(my_sys.uart_data.cache==NULL){
		my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, msg, "");
		//os_free(msg);
		return "UART No Data!";
	}else{
		my_sys.http_session.P_cache_body += os_sprintf(
					my_sys.http_session.P_cache_body, msg, my_sys.uart_data.cache);
		//os_free(msg);
		return "UART Got Data!";
	}

}


void ICACHE_FLASH_ATTR my_html_uart_rcv_do() {
	u8 * msg = NULL;

	my_html_uart_rcv_cache1();
	msg=my_html_uart_rcv_cache_msg();

	my_sys.http_session.P_cache_body += os_sprintf(
						my_sys.http_session.P_cache_body, "%s",msg);
	//os_free(msg);
	if(my_sys.uart_data.time_rcv!=NULL){
		my_sys.http_session.P_cache_body += os_sprintf(
								my_sys.http_session.P_cache_body, " @ %s",
								my_sys.uart_data.time_rcv);
	}

	my_html_uart_rcv_cache2();

}
