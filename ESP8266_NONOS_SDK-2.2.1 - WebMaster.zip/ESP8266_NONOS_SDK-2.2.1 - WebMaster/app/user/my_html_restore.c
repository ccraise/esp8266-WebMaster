/*
 * my_html_restore.c
 *
 *  Created on: 2019��5��23��
 *      Author: MasterChief
 */

#include "../include/my_html_restore.h"

void ICACHE_FLASH_ATTR my_html_restore_cache1() {
	my_html_cache_head();
	u8 * str = "<body><table border=\"1\">"
			"<tr><td align=\"center\">--- Restore System ---</td></tr>"
			"<form action=\"/restore\" method=\"post\">"
			"<tr><td align=\"center\">ARE YOU SURE<br>"
			"to Restore System Config ?<br>"
			"(Need Reboot)<br>"
			"<input type=\"checkbox\" name=\"a\" value=\"y\">YES!"
			"</td></tr>"
			"<tr><td align=\"center\">"
			"<input type=\"submit\" value=\"Restore System\" />"
			"</td></tr></form><tr><td align=\"center\">";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, "%s",str);
	//os_free(str);
}
void ICACHE_FLASH_ATTR my_html_restore_cache2() {
	u8 * str1 = "</td></tr>"
			"<tr><td align=\"center\">";
	u8 * str2 = "</td></tr></table></body></html>\n\n";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str1);
	//os_free(str1);
	my_html_cache_links();
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str2);
	//os_free(str2);
}

//�ָ�ϵͳ����Ϊ��ʼֵ
u8 * ICACHE_FLASH_ATTR my_html_restore_system() {
	u8 * a = NULL;
	a = my_HTTP_Server_Parmeter("a", PARMETER_IN_BODY);
	if (a != NULL && os_strcmp(a, "y") == 0) {
		my_SYS_Config_install_default();		//Ĭ������
		my_WiFi_init(3);		//��ʼ��wifi
		//os_free(a);
		return "System Restored!";
	} else {
		return "System Not Restored!";
	}

}

void ICACHE_FLASH_ATTR my_html_restore_do() {
	u8 * msg = NULL;

	if (my_sys.http_session.F_method == HTTP_METHOD_POST) {
		msg = my_html_restore_system();
	} else {
		msg = "Welcome!";
	}

	my_html_restore_cache1();

	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	my_html_restore_cache2();

	//my_HTTP_Server_cache_header(200);
	//my_HTTP_Server_send_cache();

}
