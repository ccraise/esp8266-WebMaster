/*
 * my_html_uart.c
 *
 *  Created on: 2019��5��28��
 *      Author: MasterChief
 */

#include "my_html_uart_prt.h"

void ICACHE_FLASH_ATTR my_html_uart_prt_cache1() {
	my_html_cache_head();
	u8 * str = "<body><table border=\"1\">"
			"<tr><td align=\"center\">--- UART Print ---</td></tr>";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, "%s",str);
	//os_free(str);
}

void ICACHE_FLASH_ATTR my_html_uart_prt_cache2() {
	u8 * str1 = "</td></tr><tr><td align=\"center\">";
	u8 * str2 = "</td></tr></table></body></html>\n\n";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, "%s",str1);
	//os_free(str1);
	my_html_cache_links();
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str2);
	//os_free(str2);
}

//�����ϴ�����
void ICACHE_FLASH_ATTR my_html_uart_prt_cache_msg(u8 * idata) {
	u8 * msg = NULL;
	msg = "<tr><td align=\"center\">Last Input</td></tr>"
			"<tr><td align=\"center\">"
			"<textarea cols=50 rows=4 readonly>%s</textarea>"
			"</td></tr>"
			"<tr><td align=\"center\">Input Somthing Here</td></tr>"
			"<form action=\"/uartp\" method=\"post\">";
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, msg, idata);
	//os_free(msg);
}

//�������,�ı����ݣ��Ƿ���ת���ַ���
void ICACHE_FLASH_ATTR my_html_uart_prt_cache_form(u8 * csig) {
	u8 * msg = NULL;
	msg = "<tr><td align=\"center\">"
			"<textarea name=\"idata\" cols=50 rows=4></textarea>"
			"</td></tr>"
			"<tr><td align=\"center\">"
			"<input type=checkbox name=csig value=1 %s>Convert Escape String"
			"</td></tr>"
			"<tr><td align=\"center\">"
			"<input type=\"reset\" value=\"RESET\">"
			"<input type=\"submit\" value=\"SUBMIT\">"
			"</td></tr></form><tr><td align=\"center\">";
	if (csig != NULL) {
		my_sys.http_session.P_cache_body += os_sprintf(
				my_sys.http_session.P_cache_body, msg, "checked");
	} else {
		my_sys.http_session.P_cache_body += os_sprintf(
				my_sys.http_session.P_cache_body, msg, "");
	}
	//os_free(msg);
	//os_free(csig);
}

//�������
u8 * ICACHE_FLASH_ATTR my_html_uart_print() {
	u8 * idata = NULL;
	u8 * csig = NULL;
	idata = my_HTTP_Server_Parmeter("idata", PARMETER_IN_BODY);
	csig = my_HTTP_Server_Parmeter("csig", PARMETER_IN_BODY);
	if (csig != NULL) {
		//����ת���ַ���ʹ��my_sys.http_session.cache������
		my_Str_URL_ES2CE(idata, my_sys.http_session.cache);
		//os_sprintf(idata,my_sys.http_session.cache);//��д
		idata = my_sys.http_session.cache; //ֱ��ָ�򻺴棬�Ȼ�д�ٶȿ�
	}
	my_html_uart_prt_cache_msg(idata); //д�뻺��
	my_html_uart_prt_cache_form(csig);
	os_printf("HTML_UART Print ->\n");
	os_printf("%s\n", idata);
	//os_free(idata);
	os_printf("HTML_UART Print -> done\n");

	return "Printed!";
}

void ICACHE_FLASH_ATTR my_html_uart_prt_do() {
	u8 * msg = NULL;

	my_html_uart_prt_cache1();
	if (my_sys.http_session.F_method == HTTP_METHOD_POST) { //�����post
		msg = my_html_uart_print();
	} else {
		my_html_uart_prt_cache_msg(""); //д�뻺��
		my_html_uart_prt_cache_form("1");
		msg = "Welcome!";
	}

	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body, "%s", msg);
	//os_free(msg);
	my_html_uart_prt_cache2();

}

