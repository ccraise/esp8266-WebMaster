/*
 * my_html_ap.c
 *
 *  Created on: 2019��5��17��
 *      Author: MasterChief
 */

#include "my_html_ap.h"

void ICACHE_FLASH_ATTR my_html_ap_cache1() {
	my_html_cache_head();
	u8 * str ="<body><table border=\"1\">"
					"<tr><td colspan=\"2\" align=\"center\">"
			"--- WiFi Config: Soft AP ---</td></tr>"
					"<form action=\"/ap\" method=\"post\">";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str);
	//os_free(str);
}

void ICACHE_FLASH_ATTR my_html_ap_cache2() {
	u8 * str1 = "</td></tr><tr><td colspan=\"2\" align=\"center\">";
	u8 * str2 = "</td></tr></table></body></html>\n\n";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str1);
	//os_free(str1);
	my_html_cache_links();
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str2);
	//os_free(str2);
}

//����apģʽ��Ϣ
void ICACHE_FLASH_ATTR my_html_ap_cache_apinfo() {
	u8 * msg = NULL;
	u8 i;
	struct softap_config apcfg;				// AP�����ṹ��
	wifi_softap_get_config(&apcfg);

	msg = "<tr><td>SSID:</td><td>"
			"<input type=\"text\" name=\"ssid\" value=\"";

	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body, msg);
	//os_free(msg);
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", apcfg.ssid);
	msg = "\" /></td></tr>"
			"<tr><td>PASS:</td>"
			"<td><input type=\"text\" name=\"pass\" value=\"";
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", apcfg.password);

	msg = "\" /></td></tr>"
			"<tr><td colspan=\"2\" align=\"center\">"
			"<input type=\"submit\" value=\"SUBMIT\" /></td></tr>"
			"</form>"
			"<tr><td colspan=\"2\" align=\"center\">";
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	//os_free(&apcfg);
}

//����ap
u8 * ICACHE_FLASH_ATTR my_html_ap_save_config() {
	//u8 * msg = NULL;
	u8 * ssid = NULL;
	u8 * pass = NULL;

	ssid = my_HTTP_Server_Parmeter("ssid", PARMETER_IN_BODY);
	pass = my_HTTP_Server_Parmeter("pass", PARMETER_IN_BODY);

	if (ssid == NULL || pass == NULL) {
		return "SSID or PASS is empty!";
	}

	if (os_strlen(pass) < 8) {
		return "SSID is too short(8 or more)!";
	}


	// ����soft-AP�������浽Flash
	if (my_AP_init(ssid,pass)) {
		return "Saved!";
	} else {
		return "Got ERROR!";
	}

}

void ICACHE_FLASH_ATTR my_html_ap_do() {
	u8 * msg = NULL;
	if (my_sys.http_session.F_method == HTTP_METHOD_POST) { //�����post
		msg = my_html_ap_save_config();
	} else {
		msg = "Welcome!";
	}

	my_html_ap_cache1();
	my_html_ap_cache_apinfo();

	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body, msg);
	//os_free(msg);
	my_html_ap_cache2();

	//my_HTTP_Server_cache_header(200);
	//my_HTTP_Server_send_cache();

}
