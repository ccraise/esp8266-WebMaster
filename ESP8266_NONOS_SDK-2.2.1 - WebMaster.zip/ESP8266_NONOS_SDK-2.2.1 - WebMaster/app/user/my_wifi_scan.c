/*
 * my_wifi_scan.c
 *
 *  Created on: 2019��5��14��
 *      Author: MasterChief
 */

#include "my_wifi_scan.h"

static void ICACHE_FLASH_ATTR my_wifi_scan_done_Cb(void *arg, STATUS status){
	os_printf("wifi scan done\n");
	//wifi_station_connect();//ɨ����ɺ�ָ�����
	if (status != OK) {
		os_printf("wifi scan error\n");
		return;
	}
	struct bss_info *bss_link = (struct bss_info *)arg;
	while(bss_link!=NULL){

		os_printf("ssid:%s\n",bss_link->ssid);


		bss_link=bss_link->next.stqe_next;
	}
}

void ICACHE_FLASH_ATTR my_wifi_scan_active_init(){
	os_printf("wifi scan init\n");
	struct scan_config config;
	config.ssid=NULL;
	config.bssid=NULL;
	config.channel=0;
	config.show_hidden=1;
	config.scan_type=WIFI_SCAN_TYPE_ACTIVE;
	config.scan_time.active.max=0;
	config.scan_time.active.min=0;
	//wifi_station_disconnect();//ɨ��ǰ�Ͽ�����
	if(wifi_station_scan(&config, my_wifi_scan_done_Cb)){
		os_printf("wifi scan init done\n");
	}else{
		os_printf("wifi scan init error \n");
	}
}

void ICACHE_FLASH_ATTR my_wifi_scan_passive_init(){
	os_printf("wifi scan init\n");
	struct scan_config config;
	config.ssid=NULL;
	config.bssid=NULL;
	config.channel=0;
	config.show_hidden=1;
	config.scan_type=WIFI_SCAN_TYPE_PASSIVE;
	config.scan_time.active.max=0;
	config.scan_time.active.min=0;
	//wifi_station_disconnect();//ɨ��ǰ�Ͽ�����
	if(wifi_station_scan(&config, my_wifi_scan_done_Cb)){
		os_printf("wifi scan init done\n");
	}else{
		os_printf("wifi scan init error \n");
	}
}
