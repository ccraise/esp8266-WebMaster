/*
 * my_sntp.c
 *
 *  Created on: 2019��5��17��
 *      Author: MasterChief
 */

#include "my_sntp.h"

//sntp��ʼ��
void ICACHE_FLASH_ATTR my_SNTP_init() {
	os_printf("SNTP init -> ");
	sntp_stop(); //��ֹͣsntp

	if (my_sys.sntp_info.domain0 == NULL) {
		my_sys.sntp_info.domain0=DEFAULT_SNTP0;
	}
	sntp_setservername(0, my_sys.sntp_info.domain0); // set server 0 by domain name
	if (my_sys.sntp_info.domain1 == NULL) {
		my_sys.sntp_info.domain1=DEFAULT_SNTP1;
	}
	sntp_setservername(1, my_sys.sntp_info.domain1); // set server 1 by domain name
	if (my_sys.sntp_info.domain2 == NULL) {
		my_sys.sntp_info.domain2=DEFAULT_SNTP2;
	}
	sntp_setservername(2, my_sys.sntp_info.domain2); // set server 2 by domain name

	sntp_set_timezone(my_sys.sntp_info.time_zone); //ʱ��
	//my_SYS_Config_save_flash();

	sntp_init(); //��ʼ��

	my_sys.sntp_info.status=1;//sntp��ʼ����
	os_printf("done\n");
}

//��ȡʱ��
/*******************************************************************************
 * FunctionName : my_SNTP_read
 * Description  : ��SNTP��������ȡʱ��,��ȡʧ�ܷ���NULL
 * Parameters   : none
 * Returns      : u8 * ʱ���ַ��� Fri May 17 11:34:33 2019
 * Examples     :
 ******************************************************************************/
u8 * ICACHE_FLASH_ATTR my_SNTP_read() {
	uint32 current_stamp;
	current_stamp = sntp_get_current_timestamp();
	if (current_stamp == 0) {
		return NULL;
	} else {
		//���÷��ͻ���
		return (u8 *) sntp_get_real_time(current_stamp);
	}
}

