/*
 * my_html_sys_cfg.c
 *
 *  Created on: 2019��5��22��
 *      Author: MasterChief
 */

#include "my_html_sys_cfg.h"

void ICACHE_FLASH_ATTR my_html_sys_cache1() {
	my_html_cache_head();
	u8 * str = "<body><table border=\"1\">"
			"<tr><td colspan=\"2\" align=\"center\">"
			"--- System Config ---</td></tr>"
			"<tr align=\"center\"><td>%s</td><td>%s</td></tr>"
			"<form action=\"/sys\" method=\"post\">";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body, str,
			my_sys.project_info.project_name,
			my_sys.project_info.software_version);
	//os_free(str);
}

void ICACHE_FLASH_ATTR my_html_sys_cache2() {
	u8 * str1 = "</td></tr><tr><td colspan=\"2\" align=\"center\">";
	u8 * str2 = "</td></tr></table></body></html>\n\n";
	//д�뷢�ͻ��棬�����¿�д��λ��
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str1);
	//os_free(str1);
	my_html_cache_links();
	my_sys.http_session.P_cache_body += os_sprintf(
			my_sys.http_session.P_cache_body,"%s", str2);
	//os_free(str2);
}

//����apģʽ��Ϣ
void ICACHE_FLASH_ATTR my_html_sys_cache_current() {
	u8 * msg = NULL;

	//check point
	msg = "<tr><td colspan=\"2\" align=\"center\">"
			"Check Point Interval:</td></tr>"
			"<tr><td><input type=\"text\" name=\"ckp\" value=\"";

	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body, "%d", my_sys.check_point);
	//os_free(msg);
	msg = "\" /></td><td>5s ~ 86,400s(24h)</td></tr>";
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	//session
	msg = "<tr><td colspan=\"2\" align=\"center\">"
			"HTTP Session Alive Time:</td></tr>"
			"<tr><td><input type=\"text\" name=\"sesn\" value=\"";

	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body, "%d",
			my_sys.http_session.alive_time);

	msg = "\" /></td><td>0s ~ 7,200s(Need Reboot)</td></tr>";
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	//os_timer
	msg = "<tr><td colspan=\"2\" align=\"center\">"
			"OS_Timer Interval:</td></tr>"
			"<tr><td><input type=\"text\" name=\"otm\" value=\"";

	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body, "%d",
			my_sys.my_timer.interval);

	msg = "\" /></td><td>5ms ~ 6,870,947ms</td></tr>";
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	msg = "<tr><td colspan=\"2\" align=\"center\">"
			"<input type=\"submit\" value=\"SUBMIT\" />"
			"</td></tr></form>"
			"<tr><td colspan=\"2\" align=\"center\">";
	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
}

//����ap
u8 * ICACHE_FLASH_ATTR my_html_sys_set() {
	u8 * msg = NULL;
	u8 * ckp = NULL;
	u8 * sesn = NULL;
	u8 * otm = NULL;
	u32 c, s, o;

	ckp = my_HTTP_Server_Parmeter("ckp", PARMETER_IN_BODY);
	sesn = my_HTTP_Server_Parmeter("sesn", PARMETER_IN_BODY);
	otm = my_HTTP_Server_Parmeter("otm", PARMETER_IN_BODY);

	if (ckp == NULL || sesn == NULL || otm == NULL) {
		//os_free(ckp);
		//os_free(sesn);
		//os_free(otm);
		return "Input is empty!";
	}

	c = atoi(ckp);
	s = atoi(sesn);
	o = atoi(otm);

	//os_free(ckp);
	//os_free(sesn);
	//os_free(otm);

	if (c < 5 || c > 86400) {
		return "Check_Point Overflow!";
	}

	if (s < 0 || s > 7200) {
		return "Session_Alive Overflow!";
	}

	if (o < 0 || o > 6870947) {
		return "Timer_Interval Overflow!";
	}

	my_sys.check_point = c;
	my_sys.http_session.alive_time = s;
	my_sys.my_timer.interval = o;

	my_SYS_Config_save_flash();

	//my_Check_Point_init();
	//my_HTTP_Server_init();

	return "Saved!";

}

void ICACHE_FLASH_ATTR my_html_sys_do() {
	u8 * msg = NULL;
	if (my_sys.http_session.F_method == HTTP_METHOD_POST) { //�����post
		msg = my_html_sys_set();
	} else {
		msg = "Welcome!";
	}

	my_html_sys_cache1();
	my_html_sys_cache_current();

	my_sys.http_session.P_cache_body +=
	os_sprintf(my_sys.http_session.P_cache_body,"%s", msg);
	//os_free(msg);
	my_html_sys_cache2();

	//my_HTTP_Server_cache_header(200);
	//my_HTTP_Server_send_cache();

}
