/*
 * my_html_uart_rcv.h
 *
 *  Created on: 2019��5��29��
 *      Author: MasterChief
 */

#ifndef __MY_HTML_UART_RCV_H_
#define __MY_HTML_UART_RCV_H_

#include "my_common.h"

void ICACHE_FLASH_ATTR my_html_uart_rcv_do();

#endif
