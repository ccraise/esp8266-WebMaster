/*
 * my_html_sys_cfg.h
 *
 *  Created on: 2019��5��22��
 *      Author: MasterChief
 */

#ifndef __MY_HTML_SYS_CFG_H_
#define __MY_HTML_SYS_CFG_H_

#include "my_common.h"

void ICACHE_FLASH_ATTR my_html_sys_do();

#endif
