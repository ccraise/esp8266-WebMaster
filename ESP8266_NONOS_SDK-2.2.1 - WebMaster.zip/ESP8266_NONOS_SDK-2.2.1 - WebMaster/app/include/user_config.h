/*
 * ESPRESSIF MIT License
 *
 * Copyright (c) 2016 <ESPRESSIF SYSTEMS (SHANGHAI) PTE LTD>
 *
 * Permission is hereby granted for use on ESPRESSIF SYSTEMS ESP8266 only, in which case,
 * it is free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef __USER_CONFIG_H__
#define __USER_CONFIG_H__

#include "my_common.h"		// �û��Զ���ͨ�ú�����
#include "my_main.h"//�û������к���
#include "my_gpio.h"
#include "my_uart.h"
#include "my_os_timer.h"
#include "my_hw_timer.h"
#include "my_task.h"
#include "my_flash.h"
#include "my_dht11.h"
#include "my_tcp_server.h"
#include "my_udp.h"
#include "my_wifi_mode.h"
#include "my_http_server.h"
#include "my_daemon.h"
#include "my_define.h"
#include "my_http_client.h"
#include "my_tcp_client.h"
#include "my_wifi_scan.h"
#include "my_web_checker.h"
#include "my_sntp.h"

#include "my_html_index.h"
#include "my_html_wifi_scan.h"
#include "my_html_config_sta.h"
#include "my_html_login.h"
#include "my_html_common.h"
#include "my_html_web_check.h"
#include "my_html_sntp.h"
#include "my_html_ap.h"
#include "my_html_admin.h"
#include "my_html_restore.h"
#include "my_html_sys_cfg.h"
#include "my_html_uart_prt.h"
#include "my_html_uart_rcv.h"
#include "my_html_gpio.h"


#endif

