/*
 * my_html_error.h
 *
 *  Created on: 2019��5��9��
 *      Author: MasterChief
 */

#ifndef __MY_HTML_ERROR_H_
#define __MY_HTML_ERROR_H_

#include "my_common.h"
#include "my_http_server.h"

//ִ��errorҳ�洦��
void ICACHE_FLASH_ATTR my_html_error_do(u8 * msg);

#endif
