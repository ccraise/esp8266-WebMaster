/*
 * my_html_wifi_scan.h
 *
 *  Created on: 2019��5��10��
 *      Author: MasterChief
 */

#ifndef __MY_HTML_WIFI_SCAN_H_
#define __MY_HTML_WIFI_SCAN_H_

#include "my_common.h"
#include "my_http_server.h"
#include "my_html_error.h"

extern struct WiFi_Scanner html_wifi_scanner;

//ִ��wifi scanҳ�洦��
void ICACHE_FLASH_ATTR my_html_wifi_scan_do();

#endif
