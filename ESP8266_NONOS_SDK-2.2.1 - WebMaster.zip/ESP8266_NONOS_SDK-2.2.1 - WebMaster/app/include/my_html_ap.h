/*
 * my_html_ap.h
 *
 *  Created on: 2019��5��17��
 *      Author: MasterChief
 */

#ifndef __MY_HTML_AP_H_
#define __MY_HTML_AP_H_

#include "my_common.h"

void ICACHE_FLASH_ATTR my_html_ap_do();

#endif
