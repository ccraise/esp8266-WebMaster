/*
 * my_html_login.h
 *
 *  Created on: 2019��5��13��
 *      Author: MasterChief
 */

#ifndef __MY_HTML_LOGIN_H_
#define __MY_HTML_LOGIN_H_

#include "my_common.h"
#include "my_http_server.h"
#include "my_html_error.h"

//#define HTML_USERID "admin"
//#define HTML_PASSWORD "admin"

void ICACHE_FLASH_ATTR my_html_login_do();

#endif
