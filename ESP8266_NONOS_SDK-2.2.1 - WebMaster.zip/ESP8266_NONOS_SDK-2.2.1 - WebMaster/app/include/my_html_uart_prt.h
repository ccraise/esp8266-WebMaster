/*
 * my_html_uart.h
 *
 *  Created on: 2019��5��28��
 *      Author: MasterChief
 */

#ifndef __MY_HTML_UART_PRT_H_
#define __MY_HTML_UART_PRT_H_

#include "my_common.h"

void ICACHE_FLASH_ATTR my_html_uart_prt_do();

#endif
