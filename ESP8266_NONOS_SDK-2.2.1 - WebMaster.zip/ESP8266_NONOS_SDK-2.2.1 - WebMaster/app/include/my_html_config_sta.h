/*
 * my_html_config_sta.h
 *
 *  Created on: 2019��5��10��
 *      Author: MasterChief
 */

#ifndef __MY_HTML_CONFIG_STA_H_
#define __MY_HTML_CONFIG_STA_H_

#include "my_common.h"
#include "my_http_server.h"
#include "my_html_error.h"


//ִ��sta����ҳ�洦��
void ICACHE_FLASH_ATTR my_html_config_sta_do();

#endif
