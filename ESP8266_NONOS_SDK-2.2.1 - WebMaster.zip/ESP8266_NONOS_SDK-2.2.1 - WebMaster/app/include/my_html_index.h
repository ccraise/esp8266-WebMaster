/*
 * my_html_index.h
 *
 *  Created on: 2019��5��8��
 *      Author: MasterChief
 */

#ifndef __MY_HTML_INDEX_H_
#define __MY_HTML_INDEX_H_

#include "my_common.h"
#include "my_http_server.h"
#include "my_html_error.h"


//ִ��indexҳ�洦��
void ICACHE_FLASH_ATTR my_html_index_do();


#endif
