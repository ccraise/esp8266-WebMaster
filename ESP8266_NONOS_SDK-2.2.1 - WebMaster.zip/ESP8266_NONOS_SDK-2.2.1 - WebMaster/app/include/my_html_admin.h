/*
 * my_html_admin.h
 *
 *  Created on: 2019��5��20��
 *      Author: MasterChief
 */

#ifndef __MY_HTML_ADMIN_H_
#define __MY_HTML_ADMIN_H_

#include "my_common.h"

void ICACHE_FLASH_ATTR my_html_admin_do();

#endif
