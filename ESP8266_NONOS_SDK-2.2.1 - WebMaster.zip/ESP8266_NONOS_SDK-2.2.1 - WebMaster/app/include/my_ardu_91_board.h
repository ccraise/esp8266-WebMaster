/*
 * my_ardu_91_board.h
 *
 *  Created on: 2019��5��21��
 *      Author: MasterChief
 */

#ifndef __MY_ARDU_91_BOARD_H_
#define __MY_ARDU_91_BOARD_H_

#include "my_common.h"

//----------------���arduino 9in1 ��չ��:-------------------------------------
//arduino 9in1 ��չ��->arduino->Wemos D1R2->esp8266
//led_blue           ->D13   ->D14       ->gpio14
//led_red            ->D12   ->D6        ->gpio12
//sw1                ->D2    ->D0        ->gpio16
//sw2                ->D3    ->D1        ->gpio5
//led_rgb(r��g)      ->D9��D1  ->D7        ->gpio13
//led_rgb(b)        ->D10     ->D8        ->gpio15

#define LED_RED 12
#define LED_BLUE 14
#define LED_RG 13
#define LED_B 15
#define SW1 16
#define SW2 5

struct Arduino_9in1_board{
	u8 F_LED_BLUE; // ��ɫLED״̬��־λ
	u8 F_LED_RED; // ��ɫLED״̬��־λ
	u8 F_LED_RG; // rgb����״̬��־λ
	u8 F_LED_B; // rgb��״̬��־λ
};


//��չ���ʼ��
void ICACHE_FLASH_ATTR my_Ardu91_init();

#endif
