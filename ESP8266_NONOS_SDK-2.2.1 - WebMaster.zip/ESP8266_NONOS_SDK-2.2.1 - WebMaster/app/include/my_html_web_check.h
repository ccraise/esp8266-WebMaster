/*
 * my_html_web_check.h
 *
 *  Created on: 2019��5��15��
 *      Author: MasterChief
 */

#ifndef __MY_HTML_WEB_CHECK_H_
#define __MY_HTML_WEB_CHECK_H_

#include "my_common.h"
#include "my_http_server.h"
#include "my_html_error.h"

void ICACHE_FLASH_ATTR my_html_web_do();

#endif
